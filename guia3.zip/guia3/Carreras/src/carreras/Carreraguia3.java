package carreras;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
public class Carreraguia3 extends javax.swing.JFrame {
    StringBuilder texto = new StringBuilder();
    Timer[] timers = new Timer[10];      
    long[] endTimes = new long[10];
    long[] startTimes = new long[10];
    int[] x= new int[501];
    int speed = 10;
    int auto=2;
    int champ = 0; 
    int apuesta;

    public void posicion(int inicio) {
        if (x[inicio] < 250) { 
            switch (inicio) {
                case 1 -> {
                    x[inicio]++;
                    carro1.setLocation(x[inicio], 32);}
                case 2 -> {
                    x[inicio]++;
                    carro2.setLocation(x[inicio], 106);}
                case 3 -> {
                    x[inicio]++;
                    carro3.setLocation(x[inicio], 150);}
                case 4 -> {
                    x[inicio]++;
                    carro4.setLocation(x[inicio], 214);}
                case 5 -> {
                    x[inicio]++;
                    carro5.setLocation(x[inicio], 258);}
                case 6 -> {
                    x[inicio]++;
                    carro6.setLocation(x[inicio], 292);}
                case 7 -> {
                    x[inicio]++;
                    carro7.setLocation(x[inicio], 336);}
                case 8 -> {
                    x[inicio]++;
                    carro8.setLocation(x[inicio], 380);}
                case 9 -> {
                    x[inicio]++;
                    carro9.setLocation(x[inicio], 424);}
                case 10 -> {
                    x[inicio]++;
                    carro10.setLocation(x[inicio], 468);}
            }
        } else {
            timers[inicio - 1].stop();
            endTimes[inicio-1] = System.currentTimeMillis();
            if(champ == 0) {
              ganador(inicio);
            } else {
                listaLlegada(inicio);
            }
            
            
        }
    }

    public void ganador(int gano){
        long totalTime = endTimes[gano-1] - startTimes[gano-1];
        texto.append("El ganador fue Carro #").append(gano).append("\t Su tiempo fue:").append(totalTime);
        champ=gano;
        
        
        jTextArea1.setText(texto.toString());
        if(champ == apuesta) {
             ganoApuesta();
        }else{
            perdioApuesta();
        }
       
    }
    
    public void listaLlegada(int carro) {
         long totalTime = endTimes[carro-1] - startTimes[carro-1];
        texto.append("\n").append(auto).append(". Carro #").append(carro).append("\t Su tiempo fue:").append(totalTime);
        auto++;
        jTextArea1.setText(texto.toString());
    }
    
    public void ganoApuesta() {
        texto.append("\ngano la apuesta :D Carro #").append(champ);
        jTextArea1.setText(texto.toString());
    }
    public void perdioApuesta() {
        texto.append("\nperdio la apuesta");
        jTextArea1.setText(texto.toString());
    }
 
    public Carreraguia3() {
        initComponents();
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        carro1 = new javax.swing.JButton();
        carro2 = new javax.swing.JButton();
        carro4 = new javax.swing.JButton();
        carro3 = new javax.swing.JButton();
        carro5 = new javax.swing.JButton();
        carro6 = new javax.swing.JButton();
        carro7 = new javax.swing.JButton();
        carro8 = new javax.swing.JButton();
        carro9 = new javax.swing.JButton();
        carro10 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        Carroapuesta = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        Iniciar = new javax.swing.JToggleButton();
        jSlider2 = new javax.swing.JSlider();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 255, 102));
        jPanel1.setToolTipText("");

        carro1.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto1.png")); // NOI18N
        carro1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro1ActionPerformed(evt);
            }
        });

        carro2.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto2.jpeg")); // NOI18N
        carro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro2ActionPerformed(evt);
            }
        });

        carro4.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto4.png")); // NOI18N
        carro4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro4ActionPerformed(evt);
            }
        });

        carro3.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto3.jpeg")); // NOI18N
        carro3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro3ActionPerformed(evt);
            }
        });

        carro5.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto5.jpeg")); // NOI18N
        carro5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro5ActionPerformed(evt);
            }
        });

        carro6.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto6.jpeg")); // NOI18N
        carro6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro6ActionPerformed(evt);
            }
        });

        carro7.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto7.jpeg")); // NOI18N

        carro8.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto8.png")); // NOI18N

        carro9.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto9.jpg")); // NOI18N
        carro9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro9ActionPerformed(evt);
            }
        });

        carro10.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\auto10.jpg")); // NOI18N
        carro10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carro10ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel11.setIcon(new javax.swing.ImageIcon("C:\\Users\\jlope\\OneDrive\\Escritorio\\guia3\\Carreras\\src\\carreras\\img\\descarga.png")); // NOI18N

        Carroapuesta.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        Carroapuesta.setText("Digite el numero del carro por el que quiere apostar");
        Carroapuesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CarroapuestaActionPerformed(evt);
            }
        });

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane3.setViewportBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane3.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        jScrollPane3.setHorizontalScrollBar(null);

        jTextArea3.setColumns(20);
        jTextArea3.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        jTextArea3.setRows(5);
        jTextArea3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextArea3KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextArea3KeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(jTextArea3);

        Iniciar.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        Iniciar.setText("START");
        Iniciar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Iniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IniciarActionPerformed(evt);
            }
        });

        jSlider2.setFont(new java.awt.Font("Comic Sans MS", 1, 12)); // NOI18N
        jSlider2.setPaintLabels(true);
        jSlider2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jSlider2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSlider2StateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(34, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(carro10)
                    .addComponent(carro1)
                    .addComponent(carro2)
                    .addComponent(carro3)
                    .addComponent(carro4)
                    .addComponent(carro5)
                    .addComponent(carro6)
                    .addComponent(carro7)
                    .addComponent(carro8)
                    .addComponent(carro9))
                .addGap(194, 194, 194)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jSlider2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Iniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(Carroapuesta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(carro1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(carro9)
                        .addGap(11, 11, 11)
                        .addComponent(carro10))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(Carroapuesta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Iniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jSlider2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSlider2StateChanged

        speed  = Math.abs(jSlider2.getValue() -
            100);
        for (Timer timer : timers) {
            timer.setDelay(speed);
        }

    }//GEN-LAST:event_jSlider2StateChanged

    private void IniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IniciarActionPerformed

        for (int i = 0; i < 10; i++) {
            final int inicio = i+1;
            int delay = (int) (Math.random() * 10);
            timers[i] = new Timer(delay, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    posicion(inicio);
                }
            });
            startTimes[i] = System.currentTimeMillis();
            timers[i].start();
        }
    }//GEN-LAST:event_IniciarActionPerformed

    private void jTextArea3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextArea3KeyReleased

        apuesta = Integer.parseInt(jTextArea3.getText());
    }//GEN-LAST:event_jTextArea3KeyReleased

    private void jTextArea3KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextArea3KeyPressed

            // TODO add your handling code here:
    }//GEN-LAST:event_jTextArea3KeyPressed

    private void CarroapuestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CarroapuestaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CarroapuestaActionPerformed

    private void carro10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro10ActionPerformed

    private void carro9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro9ActionPerformed

    private void carro6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro6ActionPerformed

    private void carro5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro5ActionPerformed

    private void carro3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro3ActionPerformed

    private void carro4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro4ActionPerformed

    private void carro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro2ActionPerformed

    private void carro1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carro1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_carro1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Carreraguia3().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Carroapuesta;
    private javax.swing.JToggleButton Iniciar;
    private javax.swing.JButton carro1;
    private javax.swing.JButton carro10;
    private javax.swing.JButton carro2;
    private javax.swing.JButton carro3;
    private javax.swing.JButton carro4;
    private javax.swing.JButton carro5;
    private javax.swing.JButton carro6;
    private javax.swing.JButton carro7;
    private javax.swing.JButton carro8;
    private javax.swing.JButton carro9;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSlider jSlider2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea3;
    // End of variables declaration//GEN-END:variables
}
